import java.util.Scanner;

public class Tienda {
    private Producto[] productos;
    private int totalProductos;
    private final int MAX = 50;
    private Scanner sc;

    public Tienda() {
        productos = new Producto[MAX];
        totalProductos = 0;
        sc = new Scanner(System.in);
    }

    public void mostrarMenu() {
        int opcion;
        do {
            System.out.println("\n--- MENÚ TIENDA ---");
            System.out.println("1. Agregar producto");
            System.out.println("2. Ver productos");
            System.out.println("3. Buscar producto");
            System.out.println("4. Modificar producto");
            System.out.println("5. Salir");
            System.out.print("Elige una opción: ");
            opcion = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> agregarProducto();
                case 2 -> verProductos();
                case 3 -> buscarProducto();
                case 4 -> modificarProducto();
                case 5 -> System.out.println("Saliendo del sistema...");
                default -> System.out.println("Opción inválida.");
            }
        } while (opcion != 5);
    }

    private void agregarProducto() {
        if (totalProductos < MAX) {
            System.out.print("Nombre: ");
            String nombre = sc.nextLine();

            System.out.print("Precio: ");
            double precio = sc.nextDouble();

            System.out.print("Cantidad: ");
            int cantidad = sc.nextInt();
            sc.nextLine(); // limpiar buffer

            productos[totalProductos] = new Producto(nombre, precio, cantidad);
            totalProductos++;
            System.out.println("Producto agregado.");
        } else {
            System.out.println("Límite máximo alcanzado.");
        }
    }

    private void verProductos() {
        if (totalProductos == 0) {
            System.out.println("No hay productos.");
        } else {
            System.out.println("\n--- LISTA DE PRODUCTOS ---");
            for (int i = 0; i < totalProductos; i++) {
                System.out.print((i + 1) + ". ");
                productos[i].mostrar();
            }
        }
    }

    private void buscarProducto() {
        System.out.print("Nombre del producto a buscar: ");
        String nombre = sc.nextLine();
        boolean encontrado = false;

        for (int i = 0; i < totalProductos; i++) {
            if (productos[i].getNombre().equalsIgnoreCase(nombre)) {
                System.out.println("Producto encontrado:");
                productos[i].mostrar();
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Producto no encontrado.");
        }
    }

    private void modificarProducto() {
        System.out.print("Nombre del producto a modificar: ");
        String nombre = sc.nextLine();
        boolean encontrado = false;

        for (int i = 0; i < totalProductos; i++) {
            if (productos[i].getNombre().equalsIgnoreCase(nombre)) {
                System.out.print("Nuevo precio: ");
                double nuevoPrecio = sc.nextDouble();
                System.out.print("Nueva cantidad: ");
                int nuevaCantidad = sc.nextInt();
                sc.nextLine(); // limpiar buffer

                productos[i].setPrecio(nuevoPrecio);
                productos[i].setCantidad(nuevaCantidad);

                System.out.println("Producto modificado.");
                encontrado = true;
                break;
            }
        }

        if (!encontrado) {
            System.out.println("Producto no encontrado.");
        }
    }
}
