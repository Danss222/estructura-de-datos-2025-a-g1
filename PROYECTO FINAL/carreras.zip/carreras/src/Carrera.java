import java.util.Random;

public class Carrera {
    private Auto[] autos; // Arreglo de autos que participan
    private int distanciaMeta;

    // Constructor
    public Carrera(Auto[] autos, int distanciaMeta) {
        this.autos = autos;
        this.distanciaMeta = distanciaMeta;
    }

    // Método que simula la carrera completa
    public void iniciarCarrera() {
        boolean hayGanador = false;
        int turno = 1;

        while (!hayGanador) {
            System.out.println("=== Turno " + turno + " ===");
            for (Auto auto : autos) {
                auto.avanzar();            // Cada auto avanza según su velocidad
                auto.mostrarPosicion();    // Mostrar su nueva posición

                // Verificar si llegó a la meta
                if (auto.getPosicion() >= distanciaMeta) {
                    System.out.println("\n🏆 ¡" + auto.getMarca() + " ha ganado la carrera! 🏆");
                    hayGanador = true;
                    break;
                }
            }

            turno++;

            // Pausa visual (opcional)
            try {
                Thread.sleep(1000); // Espera 1 segundo
            } catch (InterruptedException e) {
                System.out.println("Error en la pausa");
            }
        }
    }
}