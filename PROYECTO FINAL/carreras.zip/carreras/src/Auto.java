public class Auto {
    // Atributos privados (encapsulamiento)
    private String marca;
    private int velocidad; // Velocidad por turno
    private int posicion;  // Posición en la pista

    // Constructor
    public Auto(String marca, int velocidad) {
        this.marca = marca;
        this.velocidad = velocidad;
        this.posicion = 0;
    }

    // Método para avanzar (simula movimiento)
    public void avanzar() {
        posicion += velocidad;
    }

    // Getters
    public String getMarca() {
        return marca;
    }

    public int getPosicion() {
        return posicion;
    }

    // Mostrar información del auto
    public void mostrarPosicion() {
        System.out.println(marca + " está en la posición " + posicion + " metros.");
    }
}