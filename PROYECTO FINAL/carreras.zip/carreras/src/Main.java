public class Main {
    public static void main(String[] args) {
        // Crear autos
        Auto auto1 = new Auto("Toyota", 10);    // Avanza 10 metros por turno
        Auto auto2 = new Auto("Ferrari", 12);   // Avanza 12 metros por turno
        Auto auto3 = new Auto("Nissan", 9);     // Avanza 9 metros por turno

        // Arreglo con los autos participantes
        Auto[] listaAutos = { auto1, auto2, auto3 };

        // Crear la carrera (meta de 100 metros)
        Carrera carrera = new Carrera(listaAutos, 100);

        // Iniciar la carrera
        carrera.iniciarCarrera();
    }
}